#include "testtradeapi.h"

CTestTradeApi::CTestTradeApi(CThostFtdcTraderApi *pTradeUserApi,const TThostFtdcBrokerIDType BrokerID,
	const TThostFtdcUserIDType UserID,const TThostFtdcPasswordType Password,
	const TThostFtdcInstrumentIDType InstrumentID)
{
	m_pTradeUserApi=pTradeUserApi;

	memset(&m_ReqLoginPackage,0,sizeof(CThostFtdcReqUserLoginField));
	strcpy(m_ReqLoginPackage.BrokerID,BrokerID);
	strcpy(m_ReqLoginPackage.UserID,UserID);
	strcpy(m_ReqLoginPackage.Password,Password);
	strcpy(m_InstrumentID,InstrumentID);
}
	
CTestTradeApi::~CTestTradeApi()
{
}

void CTestTradeApi::getInvestorRange(const TThostFtdcInvestorRangeType &InvestorRange,char *pRangeName)
{
	switch(InvestorRange)
	{
	case THOST_FTDC_IR_All:
		strcpy(pRangeName, "����Ͷ����");
	case THOST_FTDC_IR_Group:
		strcpy(pRangeName,"Ͷ������");
	case THOST_FTDC_IR_Single:
		strcpy(pRangeName, "��һͶ����");
	}
}

///���ͻ����뽻�׺�̨������ͨ������ʱ����δ��¼ǰ�����÷��������á�
void CTestTradeApi::OnFrontConnected()
{
	if (m_pTradeUserApi->ReqUserLogin(&m_ReqLoginPackage,0))
	{
		printf("���͵�½����ʧ��\n\n");
	}
}
		
///������ʱ���档����ʱ��δ�յ�����ʱ���÷��������á�
///@param nTimeLapse �����ϴν��ձ��ĵ�ʱ��
void CTestTradeApi::OnHeartBeatWarning(int nTimeLapse)
{
}

///�û���¼Ӧ��
void CTestTradeApi::OnRspUserLogin(CThostFtdcRspUserLoginField *pRspUserLogin, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	if (pRspInfo && pRspInfo->ErrorID==0)
	{
		CThostFtdcQryInstrumentMarginRateField QryInstrumentMarginRate;
		memset(&QryInstrumentMarginRate,0,sizeof(QryInstrumentMarginRate));
		strcpy(QryInstrumentMarginRate.BrokerID,m_ReqLoginPackage.BrokerID);
		strcpy(QryInstrumentMarginRate.InvestorID,m_ReqLoginPackage.UserID);
		strcpy(QryInstrumentMarginRate.InstrumentID,m_InstrumentID);
		QryInstrumentMarginRate.HedgeFlag='1';
		if (m_pTradeUserApi->ReqQryInstrumentMarginRate(&QryInstrumentMarginRate,1))
		{
			printf("����ReqQryInstrumentMarginRate����ʧ��\n\n");
		}

		return;
	}
	else if (pRspInfo)
	{
		printf("�û���¼Ӧ��:errid=[%d] errmsg=[%s]\n",pRspInfo->ErrorID,pRspInfo->ErrorMsg);
	}
}

///�����ѯ��Լ��֤������Ӧ
void CTestTradeApi::OnRspQryInstrumentMarginRate(CThostFtdcInstrumentMarginRateField *pInstrumentMarginRate, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	if (pRspInfo)
	{
		printf("��ѯ��Լ��֤������Ӧ:errid=[%d] errmsg=[%s]\n",pRspInfo->ErrorID,pRspInfo->ErrorMsg);
	}
	if (pInstrumentMarginRate)
	{
		char sRangeName[64];
		memset(sRangeName,0,sizeof(sRangeName));
		getInvestorRange(pInstrumentMarginRate->InvestorRange,sRangeName);
		printf("InstrumentID=%s InvestorRange=%s BrokerID=%s InvestorID=%s HedgeFlag=%c LongMarginRatioByMoney=%.2f LongMarginRatioByVolume=%.2f ShortMarginRatioByMoney=%.2f ShortMarginRatioByVolume=%.2f IsRelative=%s\n", \
			pInstrumentMarginRate->InstrumentID, sRangeName, \
			pInstrumentMarginRate->BrokerID, \
			pInstrumentMarginRate->InvestorID, \
			pInstrumentMarginRate->HedgeFlag, \
			pInstrumentMarginRate->LongMarginRatioByMoney, \
			pInstrumentMarginRate->LongMarginRatioByVolume, \
			pInstrumentMarginRate->ShortMarginRatioByMoney, \
			pInstrumentMarginRate->ShortMarginRatioByVolume, \
			pInstrumentMarginRate->IsRelative==1?"������":"�ǽ�����");
	}
}

int main(int argc, char **argv)
{
	if (argc<6)
	{
		printf("Usage:testtradeapi tcp://xxx.xxx.xxx.xxx:port BrokerID userID Passwd InstrumentID\n");
		return -1;
	}

	CThostFtdcTraderApi *pTradeUserApi = CThostFtdcTraderApi::CreateFtdcTraderApi("");
	CTestTradeApi *pTestEngine = new CTestTradeApi(pTradeUserApi,argv[2],argv[3],argv[4],argv[5]);
	pTradeUserApi->SubscribePrivateTopic(THOST_TERT_QUICK);	// ע��˽����
	pTradeUserApi->SubscribePublicTopic(THOST_TERT_QUICK);	// ע�ṫ����

	pTradeUserApi->RegisterFront(argv[1]);

	pTradeUserApi->RegisterSpi(pTestEngine);
	pTradeUserApi->Init();
	pTradeUserApi->Join();

	delete pTestEngine;
	pTradeUserApi->Release();

	return 0;
}
